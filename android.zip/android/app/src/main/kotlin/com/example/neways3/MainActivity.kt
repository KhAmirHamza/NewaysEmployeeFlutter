package com.example.neways3

//import io.flutter.embedding.android.FlutterActivity
//import io.flutter

class MainActivity: FlutterActivity() {
}
