// To parse this JSON data, do
//
//     final fileModel = fileModelFromJson(jsonString);

import 'dart:convert';
import 'dart:io';

List<FileModel> fileModelFromJson(String str) =>
    List<FileModel>.from(json.decode(str).map((x) => FileModel.fromJson(x)));

String fileModelToJson(List<FileModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

List fileModelToPath(List<FileModel> data) =>
    List<dynamic>.from(data.map((x) => x.toPath()));

class FileModel {
  FileModel({
    required this.file,
    this.extention,
  });

  File file;
  dynamic extention;

  factory FileModel.fromJson(Map<String, dynamic> json) => FileModel(
        file: json["file"],
        extention: json["extention"],
      );

  Map<String, dynamic> toJson() => {
        "file": file,
        "extention": extention,
      };
  Map<String, dynamic> toPath() => {
        "file": file.path,
        "extention": extention,
      };
}
