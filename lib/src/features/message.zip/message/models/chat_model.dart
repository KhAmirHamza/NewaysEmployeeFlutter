// To parse this JSON data, do
//
//     final chatModel = chatModelFromJson(jsonString);

import 'dart:convert';

ChatModel chatModelFromJson(String str) => ChatModel.fromJson(json.decode(str));

String chatModelToJson(ChatModel data) => json.encode(data.toJson());

class ChatModel {
  ChatModel({
    this.id,
    this.name,
    this.avatar,
    this.isGroup,
    this.time,
    this.currentMessage,
    this.status,
    this.select,
    this.designation,
  });

  dynamic id;
  dynamic name;
  dynamic avatar;
  dynamic isGroup;
  dynamic time;
  dynamic currentMessage;
  dynamic status;
  dynamic select;
  dynamic designation;

  factory ChatModel.fromJson(Map<String, dynamic> json) => ChatModel(
        id: json["id"],
        name: json["name"],
        avatar: json["avatar"],
        isGroup: json["isGroup"],
        time: json["time"],
        currentMessage: json["currentMessage"],
        status: json["status"],
        select: json["select"],
        designation: json["designation"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "avatar": avatar,
        "isGroup": isGroup,
        "time": time,
        "currentMessage": currentMessage,
        "status": status,
        "select": select,
        "designation": designation,
      };
}
