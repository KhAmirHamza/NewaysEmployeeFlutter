class Message {
  final dynamic sender;
  final String? avatar;
  final String time;
  final int? unreadCount;
  final bool? isRead;
  final String text;
  final String? status;
  final List<dynamic>? files;
  final bool isFile;

  Message(
      {required this.sender,
      this.avatar,
      required this.time,
      this.unreadCount,
      required this.text,
      this.isRead,
      this.files,
      this.status,
      this.isFile = false});
}
