// To parse this JSON data, do
//
//     final conversationModel = conversationModelFromJson(jsonString);

// ignore_for_file: file_names

import 'dart:convert';

List<ConversationModel> conversationModelFromJson(List data) =>
    List<ConversationModel>.from(
        data.map((x) => ConversationModel.fromJson(x)));

String conversationModelToJson(List<ConversationModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ConversationModel {
  ConversationModel({
    this.participant,
    this.id,
    this.lastUpdated,
    this.lastMessage,
    this.message,
  });

  Participant? participant;
  dynamic id;
  dynamic lastUpdated;
  LastMessage? lastMessage;
  // send message
  dynamic message;

  factory ConversationModel.fromJson(Map<String, dynamic> json) =>
      ConversationModel(
        participant: Participant.fromJson(json["participant"]),
        id: json["id"].toString(),
        lastUpdated: json["last_updated"],
        lastMessage: LastMessage.fromJson(json["last_message"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "participant": participant!.toJson(),
        "id": id,
        "last_updated": lastUpdated,
        "last_message": lastMessage!.toJson(),
        "message": message,
      };
}

class Participant {
  Participant({
    this.employeeId,
    this.name,
    this.avatar,
    this.designation,
  });

  dynamic employeeId;
  dynamic name;
  dynamic avatar;
  dynamic designation;

  factory Participant.fromJson(Map<String, dynamic> json) => Participant(
        employeeId: json["employeeId"],
        name: json["name"],
        avatar: json["avatar"],
        designation: json["designation"],
      );

  Map<String, dynamic> toJson() => {
        "employeeId": employeeId,
        "name": name,
        "avatar": avatar,
        "designation": designation,
      };
}

class LastMessage {
  LastMessage({
    this.sender,
    this.message,
    this.status,
    this.unseen,
  });

  dynamic sender;
  dynamic message;
  dynamic status;
  dynamic unseen;

  factory LastMessage.fromJson(Map<String, dynamic> json) => LastMessage(
        sender: json["sender"],
        message: json["message"],
        status: json["status"],
        unseen: json["unseen"],
      );

  Map<String, dynamic> toJson() => {
        "sender": sender,
        "message": message,
        "status": status,
        "unseen": unseen,
      };
}
