// ignore_for_file: file_names, avoid_print, library_prefixes

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hive/hive.dart';
import 'package:neways3/src/features/message/bloc/IndividualChatController.dart';
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/features/message/services/chat_service.dart';
import 'package:neways3/src/utils/constants.dart';
import 'package:neways3/src/utils/firebaseMessage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class ChatListController extends GetxController {
  late Box box;
  late IO.Socket socket;
  List<ConversationModel> users = [];
  bool isLoading = false;
  List activeUsers = [].obs;
  bool isTyping = false;
  bool isUpdate = false;
  late String typperId = '';
  late Timer timer;
  final individualChatController = Get.put(IndividualChatController());
  @override
  void onInit() async {
    super.onInit();
    isLoading = true;
    connect();
    startTime();
    await openBox();
    getAllBoxUser();
    getAllConnectedUser();
  }

  startTime() {
    timer = Timer.periodic(const Duration(seconds: 15), (Timer t) => update());
  }

  callApi() {
    ChatService.getAllUser().then((value) {
      users = value;

      box.clear();
      for (var user in users) {
        box.add(user.toJson());
      }
      update();
    });
  }

  getAllConnectedUser() async {
    await ChatService.getAllUser().then((value) {
      users = value;
      box.clear();
      for (var user in users) {
        box.add(user.toJson());
      }

      isLoading = false;
    });
    update();
  }

  getAllBoxUser() {
    var data = box.toMap().values.toList();
    users = [];
    for (var element in data) {
      users.add(ConversationModel(
        id: element['id'],
        lastMessage: LastMessage(
          message: element['last_message']['message'],
          sender: element['last_message']['sender'].toString(),
          status: element['last_message']['status'],
        ),
        lastUpdated: element['last_updated'],
        participant: Participant(
            avatar: element['participant']['avatar'],
            designation: element['participant']['designation'],
            employeeId: element['participant']['employeeId'],
            name: element['participant']['name']),
        message: element['message'],
      ));
    }
    isLoading = false;
    update();
  }

  Future openBox() async {
    var dir = await getApplicationDocumentsDirectory();
    Hive.init(dir.path);
    box = await Hive.openBox('users');
    return;
  }

  void connect() {
    socket = IO.io('http://$socketURL', <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": false,
    });
    socket.connect();
    socket.emit("addUser", [
      GetStorage().read('employeeId'),
      {'name': GetStorage().read('name')}
    ]);
    socket.onConnect((data) {
      socket.on("getUsers", (userData) => addActiveUser(userData));
      // socket.on("getMessage", (msg) {
      //   callApi();
      //   print(msg);
      // });
      socket.on("typingMessageGet", (msg) {
        print("Typing... : $msg");
        if (msg['message'] == '') {
          isTyping = false;
          typperId = '';
        } else {
          isTyping = true;
          typperId = msg['sourceId'];
        }
        update();
      });
      socket.on("message", (msg) {
        if (msg != null) {
          if (msg['sender']['id'] ==
              individualChatController.participant.employeeId) {
            print(msg['message']);
            individualChatController.setMessage(
              sender: msg['sender']['id'],
              time: msg["date_time"],
              msg: msg['message'],
              files: msg['attachment'] != null
                  ? msg['attachment'].toString().split(',')
                  : [],
            );
            individualChatController.scrollController.animateTo(
                individualChatController
                    .scrollController.position.minScrollExtent,
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOut);
            individualChatController.seenMessage();
          }
        }
        callApi();
      });
      socket.on("seenMessage", (value) async {
        print(value);
        print(individualChatController.conversationModel.id ==
            value['conversationId']);
        if (individualChatController.conversationModel.id ==
            value['conversationId']) {
          // await individualChatController.getAllMessage();
          individualChatController.updateMesssage();
          // isUpdate = true;
        }
      });
      socket.on("pushNotification", (value) async {
        firebasePushMsg(
            topic: value['topic'], title: value['title'], body: value['body']);
      });
    });
    print("socket connected : ${socket.connected}");
  }

  setUpdate(value) {
    isUpdate = value;
    update();
  }

  addActiveUser(userData) {
    activeUsers = [];
    for (var user in userData) {
      activeUsers.add(user['userId']);
    }
    update();
  }

  disconnectSocket() {
    socket.disconnect();
  }

  sendMessage(msg, Participant participant) async {
    String time =
        "${TimeOfDay.now().hour}:${TimeOfDay.now().minute} ${TimeOfDay.now().period.toString().split("DayPeriod.")[1]}";
    socket.emit("sendMessage", {
      "message": msg,
      "time": time,
      "sourceId": GetStorage().read('employeeId'),
      "reseverId": participant.employeeId,
    });

    update();
  }

  typingMessage(msg, Participant participant) async {
    String time =
        "${TimeOfDay.now().hour}:${TimeOfDay.now().minute} ${TimeOfDay.now().period.toString().split("DayPeriod.")[1]}";
    socket.emit("typingMessage", {
      "message": msg,
      "time": time,
      "sourceId": GetStorage().read('employeeId'),
      "reseverId": participant.employeeId,
    });

    update();
  }
}
