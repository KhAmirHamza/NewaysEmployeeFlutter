// ignore_for_file: file_names, library_prefixes, avoid_print, prefer_interpolation_to_compose_strings, depend_on_referenced_packages

import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/features/message/models/chat_model.dart';
import 'package:neways3/src/features/message/models/message_model.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class IndividualChatController extends GetxController {
  late IO.Socket socket;
  bool emojiShowing = false;
  bool isReadyToSend = false;
  ChatModel auth = ChatModel();
  late ConversationModel targetUser;
  late ConversationModel conversationModel;
  List<Message> messages = [];
  TextEditingController textController = TextEditingController();

  ScrollController scrollController = ScrollController();

  // image upload ...
  final ImagePicker _picker = ImagePicker();

  late File file;
  bool isFillUpload = false;

  // @override
  // void onInit() {
  //   super.onInit();
  // }

  setConversation(ConversationModel user) {
    targetUser = user;
    conversationModel = user;

    connect();

    update();
  }

  void connect() {
    // MessageModel messageModel = MessageModel(sourceId: widget.sourceChat.id.toString(),targetId: );

    socket.disconnect();
    socket = IO.io("http://192.168.16.139:5000", <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": false,
    });
    socket.connect();
    socket.emit("signin", GetStorage().read('employeeId'));
    socket.onConnect((data) {
      print("Connected: ${data.toString()}");
      socket.on("message", (msg) {
        setMessage(
            sender: msg["sourceId"],
            time: msg["time"],
            msg: msg["message"],
            filePath: msg["filePath"],
            fileType: msg["fileType"]);
        scrollController.animateTo(scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      });
    });
    print(socket.connected);
  }

  showEmojiState(value) {
    emojiShowing = value;
    if (emojiShowing) {
      FocusManager.instance.primaryFocus?.unfocus();
    } else {
      // FocusManager.instance.primaryFocus?.focus();
    }
    update();
  }

  onBackspacePressed() {
    print('_onBackspacePressed');
  }

  onChangeMessage(msg) {
    isReadyToSend = textController.text.isNotEmpty;
    update();
  }

  sendMessage() async {
    String time =
        "${TimeOfDay.now().hour}:${TimeOfDay.now().minute} ${TimeOfDay.now().period.toString().split("DayPeriod.")[1]}";
    if (isFillUpload) {
      var path = await onImageSend();
      socket.emit("message", {
        "message": textController.text,
        "time": time,
        "sourceId": GetStorage().read('employeeId'),
        "targetId": conversationModel.participant!.employeeId,
        "fileType": isFillUpload ? 'image' : '',
        "filePath":
            isFillUpload ? "http://192.168.16.139:5000/images/" + path : ''
      });
      setMessage(
        sender: GetStorage().read('employeeId'),
        time: time,
        msg: textController.text,
        fileType: isFillUpload ? 'image' : '',
        filePath: isFillUpload ? file.path : '',
      );
    } else {
      if (textController.text.isNotEmpty) {
        socket.emit("message", {
          "message": textController.text,
          "time": time,
          "sourceId": GetStorage().read('employeeId'),
          "targetId": conversationModel.participant!.employeeId,
          "fileType": '',
          "filePath": ''
        });
        setMessage(
          sender: GetStorage().read('employeeId'),
          time: time,
          msg: textController.text,
          fileType: isFillUpload ? 'image' : '',
          filePath: isFillUpload ? file.path : '',
        );
      }
    }

    textController.clear();
    isFillUpload = false;
    isReadyToSend = textController.text.isNotEmpty;
    update();
  }

  setMessage({sender, time, msg, fileType, filePath}) {
    Message message = Message(
      sender: sender,
      time: time,
      text: msg,
    );

    messages.add(message);
    update();
  }

  // ================================= Image from camera
  Future getCameraImage(context) async {
    final XFile? photo = await _picker.pickImage(source: ImageSource.camera);

    file = File(photo!.path);
    isFillUpload = true;
    isReadyToSend = true;
    Navigator.pop(context);
    update();
  }

  //============================== Image from gallery
  Future getGalleryImage(context) async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);

    file = File(image!.path);
    isFillUpload = true;
    isReadyToSend = true;
    Navigator.pop(context);
    update();
  }

  deleteImage() {
    isFillUpload = false;
    isReadyToSend = textController.text.isNotEmpty;
    update();
  }

  onImageSend() async {
    var request = http.MultipartRequest(
        "POST", Uri.parse("http://192.168.16.139:5000/api/addImage"));
    request.files.add(await http.MultipartFile.fromPath("img", file.path));
    request.headers.addAll({
      "Content-type": "multipart/form-data",
    });
    http.StreamedResponse response = await request.send();
    var httpResponse = await http.Response.fromStream(response);
    var data = json.decode(httpResponse.body);
    print(response.statusCode);
    print(data['path']);
    return data['path'];
  }
}
