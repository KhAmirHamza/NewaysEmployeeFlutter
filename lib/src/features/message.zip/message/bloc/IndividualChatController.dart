// ignore_for_file: file_names, library_prefixes, avoid_print, prefer_interpolation_to_compose_strings, prefer_null_aware_operators, depend_on_referenced_packages

import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:neways3/src/features/message/bloc/ChatListController.dart';
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/features/message/models/file_model.dart';
import 'package:neways3/src/features/message/models/message_model.dart';
import 'package:neways3/src/features/message/services/chat_service.dart';
import 'package:neways3/src/utils/constants.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class IndividualChatController extends GetxController {
  late IO.Socket socket;
  bool emojiShowing = false;
  bool isReadyToSend = false;
  late ConversationModel conversationModel = ConversationModel();
  late Participant participant = Participant();
  List<Message> messages = [];
  TextEditingController textController = TextEditingController(text: '');

  ScrollController scrollController = ScrollController();
  bool isReverse = true;

  // image upload ...
  final ImagePicker _picker = ImagePicker();

  late List<FileModel> files = [];

  // @override
  // void onInit() {
  //   super.onInit();
  // }

  setConversation(ConversationModel user) {
    messages = [];
    files = [];
    conversationModel = user;
    participant = user.participant!;
    seenMessage();
    getAllMessage();
    // connect();
    textController.clear();
    Get.put(ChatListController()).typingMessage('', participant);
    update();
  }

  seenMessage() {
    ChatService.seenMessage(
            conversationId: conversationModel.id,
            participantId: participant.employeeId)
        .then((value) {
      update();
    });
  }

  getAllMessage() async {
    await ChatService.getAllMessage(conversationId: conversationModel.id)
        .then((value) {
      for (var element in value) {
        print(element);
        setMessage(
            sender: element['sender']['id'],
            time: element["date_time"],
            msg: element['text'],
            files: element['attachment'] != null
                ? element['attachment'].toString().split(',')
                : [],
            status: element['status'],
            isAdd: true);
      }
    });
    update();
  }

  updateMesssage() {
    List<Message> newMessages = [];
    for (var element in messages) {
      if (element.status == 'unseen') {
        newMessages.add(Message(
          sender: element.sender,
          time: element.time,
          text: element.text,
          avatar: element.avatar,
          files: element.files,
          isFile: element.isFile,
          isRead: element.isRead,
          status: 'seen',
        ));
      } else {
        newMessages.add(element);
      }
    }
    messages = newMessages;
    update();
  }

  void connect() {
    socket = IO.io('http://' + socketURL, <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": false,
    });
    socket.connect();
    socket.emit("signin", GetStorage().read('employeeId'));
    socket.onConnect((data) {
      socket.on("message", (msg) {
        print(msg);
        if (msg != null) {
          if (msg['sender']['id'] == participant.employeeId) {
            setMessage(
              sender: msg['sender']['id'],
              time: msg["date_time"],
              msg: msg['message'],
              files: msg['attachment'] != null
                  ? msg['attachment'].toString().split(',')
                  : [],
            );
            scrollController.animateTo(
                scrollController.position.minScrollExtent,
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOut);
          }
        }
      });
    });
    print(socket.connected);
  }

  showEmojiState(value) {
    emojiShowing = value;
    if (emojiShowing) {
      FocusManager.instance.primaryFocus?.unfocus();
    } else {
      // FocusManager.instance.primaryFocus?.focus();
    }
    update();
  }

  onBackspacePressed() {
    print('_onBackspacePressed');
  }

  onChangeMessage(msg) {
    Get.put(ChatListController())
        .typingMessage(textController.text, participant);
    isReadyToSend = textController.text.isNotEmpty;
    update();
  }

  sendMessage() async {
    Get.put(ChatListController()).typingMessage('', participant);
    showEmojiState(false);
    String time =
        "${TimeOfDay.now().hour}:${TimeOfDay.now().minute} ${TimeOfDay.now().period.toString().split("DayPeriod.")[1]}";

    Get.put(ChatListController()).sendMessage(textController.text, participant);
    if (files.isNotEmpty) {
      isReadyToSend = textController.text.isNotEmpty;
      setMessage(
          sender: GetStorage().read('employeeId'),
          time: time,
          msg: textController.text,
          files: files,
          isFile: true);
      dynamic paths = await onImageSend();
      print(paths);
      files = [];
      await ChatService.sendMessage(
          conversationId: conversationModel.id,
          participant: participant,
          message: textController.text,
          paths: paths.toString(),
          time: time);
    } else {
      files = [];
      isReadyToSend = textController.text.isNotEmpty;
      if (textController.text.isNotEmpty) {
        setMessage(
          sender: GetStorage().read('employeeId'),
          time: time,
          msg: textController.text,
          status: 'unseen',
        );
        await ChatService.sendMessage(
            conversationId: conversationModel.id,
            participant: participant,
            message: textController.text,
            time: time);
      }
    }

    textController.clear();

    update();
  }

  setMessage(
      {sender,
      time,
      msg,
      files,
      isAdd = false,
      isFile = false,
      status = 'unseen'}) {
    Message message = Message(
      sender: sender ?? '',
      time: time ?? '',
      text: msg ?? '',
      status: status,
      files: files,
      isFile: isFile,
    );
    if (isAdd) {
      messages.add(message);
    } else {
      messages.insert(0, message);
    }
    update();
  }

  // ================================= Image from camera
  Future getCameraImage(context) async {
    final XFile? photo = await _picker.pickImage(source: ImageSource.camera);
    files.add(FileModel(extention: 'jpg', file: File(photo!.path)));
    isReadyToSend = true;
    Navigator.pop(context);
    update();
  }

  //============================== Image from gallery
  Future getGalleryImage(context) async {
    // final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    final List<XFile> pickedFileList = await _picker.pickMultiImage(
        // maxWidth: maxWidth,
        // maxHeight: maxHeight,
        // imageQuality: quality,
        );
    for (var image in pickedFileList) {
      files.add(FileModel(extention: 'jpg', file: File(image.path)));
    }
    // file = File(image!.path);
    isReadyToSend = true;
    Navigator.pop(context);
    update();
  }

  deleteImage(index) {
    files.removeAt(index);
    if (files.isEmpty) {
      isReadyToSend = textController.text.isNotEmpty;
    }
    update();
  }

  onImageSend() async {
    var request = http.MultipartRequest(
        "POST", Uri.parse("http://$socketURL/api/addImage"));
    for (FileModel model in files) {
      request.files
          .add(await http.MultipartFile.fromPath("img", model.file.path));
    }

    files = [];
    request.headers.addAll({
      "Content-type": "multipart/form-data",
    });
    http.StreamedResponse response = await request.send();
    var httpResponse = await http.Response.fromStream(response);
    var data = json.decode(httpResponse.body);
    return data['paths'];
  }

  //============================== Image from gallery
  Future getFile(context) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: [
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'ppt',
        'pptx',
        'txt'
      ],
    );

    if (result != null) {
      // File file = File(result.files.single.path!);
      print(result.files.single.extension);
      files.add(FileModel(
          extention: result.files.single.extension,
          file: File(result.files.single.path!)));
    } else {
      // User canceled the picker
    }
    isReadyToSend = true;
    Navigator.pop(context);
    update();
  }
}
