// ignore_for_file: file_names, must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:neways3/src/features/message/bloc/ChatListController.dart';
import 'package:neways3/src/features/message/bloc/IndividualChatController.dart';
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/features/message/widgets/chat_composer.dart';
import 'package:neways3/src/features/message/widgets/conversation.dart';

class IndividualChatScreen extends StatelessWidget {
  ConversationModel user;
  IndividualChatScreen({Key? key, required this.user}) : super(key: key);
  final controller = Get.put(IndividualChatController());
  @override
  Widget build(BuildContext context) {
    // SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    //     statusBarColor: Colors.white,
    //     statusBarIconBrightness: Brightness.dark));
    controller.setConversation(user);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          elevation: 0,
          leading: InkWell(
            onTap: () async {
              controller.showEmojiState(false);
              await Get.put(ChatListController())
                  .typingMessage('', user.participant!);
              Get.back();
            },
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              size: 21,
              color: Colors.white,
            ),
          ),
          title: Column(
            children: [
              Text(
                user.participant!.name,
                style: const TextStyle(fontSize: 16),
              ),
              Text(
                user.participant!.designation,
                style: TextStyle(fontSize: 10, color: Colors.grey.shade100),
              )
            ],
          ),
          actions: [
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.call),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.video_call),
            ),
          ],
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Conversation(user: user),
              ),
            ),
            buildChatComposer(context),
          ],
        ),
      ),
    );
  }
  
}
