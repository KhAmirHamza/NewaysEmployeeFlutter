// ignore_for_file: file_names, must_be_immutable

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:neways3/src/features/contacts/presentation/AddContactScreen.dart';
import 'package:neways3/src/features/message/bloc/ChatListController.dart';
import 'package:neways3/src/features/message/components/IndividualChatScreen.dart';
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/utils/constants.dart';
import 'package:shimmer/shimmer.dart';
import 'package:timeago/timeago.dart' as timeago;

class MessageListScreen extends StatelessWidget {
  const MessageListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark));

    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: GetBuilder<ChatListController>(
          init: ChatListController(),
          builder: (controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Visibility(
                    visible: controller.isLoading,
                    child: Expanded(
                      child: ListView.builder(
                        itemCount: 20,
                        itemBuilder: ((context, index) => Shimmer.fromColors(
                              baseColor: DColors.background,
                              highlightColor: Colors.blueGrey.shade100,
                              child: Container(
                                margin: EdgeInsets.only(bottom: DPadding.full),
                                child: Row(
                                  children: [
                                    ClipRRect(
                                      borderRadius:
                                          BorderRadius.circular(DPadding.half),
                                      child: Container(
                                        width: 52,
                                        height: 52,
                                        decoration: BoxDecoration(
                                            color: Colors.grey.shade400,
                                            borderRadius: BorderRadius.circular(
                                                DPadding.half)),
                                      ),
                                    ),
                                    const WidthSpace(),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                color: Colors.grey.shade500,
                                                width: size.width * .65,
                                                height: 12,
                                              ),
                                              Container(
                                                color: Colors.grey.shade400,
                                                width: size.width * .03,
                                                height: 12,
                                              ),
                                            ],
                                          ),
                                          const HeightSpace(height: 4),
                                          Container(
                                            color: Colors.grey.shade400,
                                            width: size.width * .42,
                                            height: 8,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )),
                      ),
                    )),
                Visibility(
                  visible: !controller.isLoading,
                  child: Expanded(
                    child: ListView.builder(
                      itemCount: controller.users.length,
                      itemBuilder: (context, index) =>
                          ChatListContainer(user: controller.users[index]),
                    ),
                  ),
                ),
              ],
            );
          }),
    );
  }
}

class ChatListContainer extends StatelessWidget {
  ConversationModel user;
  ChatListContainer({
    required this.user,
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ChatListController>(
        init: ChatListController(),
        builder: (controller) {
          return InkWell(
            onTap: () async {
              await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => IndividualChatScreen(user: user)));
              controller.callApi();
            },
            child: Container(
              margin: EdgeInsets.only(bottom: DPadding.full),
              child: Row(
                children: [
                  Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(DPadding.half),
                        child: ExtendedImage.network(
                          user.participant!.avatar,
                          fit: BoxFit.fill,
                          enableLoadState: true,
                          cache: true,
                          width: 52,
                          height: 52,
                          loadStateChanged: (state) {
                            switch (state.extendedImageLoadState) {
                              case LoadState.loading:
                                return Shimmer.fromColors(
                                  baseColor: DColors.background,
                                  highlightColor: Colors.blueGrey.shade100,
                                  child: Container(
                                    color: DColors.background,
                                  ),
                                );
                              case LoadState.completed:
                                return ExtendedRawImage(
                                  image: state.extendedImageInfo?.image,
                                  width: 52,
                                  height: 52,
                                  fit: BoxFit.cover,
                                );
                              case LoadState.failed:
                                return Container(
                                  color: DColors.highLight,
                                  child: const Icon(
                                    Icons.error_outline_outlined,
                                    size: 18,
                                    color: Colors.white,
                                  ),
                                );
                            }
                          },
                        ),
                      ),
                      // Flexible(
                      //   child: Text(
                      //       timeago.format(DateTime.tryParse(
                      //           user.lastUpdated.toString())!),
                      //       style: DTextStyle.textSubTitleStyle),
                      // ),
                    ],
                  ),
                  const WidthSpace(),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              user.participant!.name,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            ),
                            Text(
                                timeago.format(DateTime.tryParse(
                                    user.lastUpdated.toString())!),
                                style: DTextStyle.textSubTitleStyle),
                          ],
                        ),
                        const HeightSpace(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            controller.isTyping &&
                                    controller.typperId ==
                                        user.participant!.employeeId
                                ? AnimatedTextKit(
                                    repeatForever: true,
                                    animatedTexts: [
                                      TyperAnimatedText(
                                        'Typing...',
                                        textStyle:
                                            DTextStyle.textSubTitleBoldStyle,
                                      ),
                                    ],
                                  )
                                : Flexible(
                                    child: Text(
                                      "${user.lastMessage!.sender == user.participant!.employeeId ? "" : "You:"} ${user.lastMessage!.message}",
                                      maxLines: 1,
                                      style: (user.lastMessage!.status ==
                                                  'unseen' &&
                                              user.lastMessage!.sender ==
                                                  user.participant!.employeeId)
                                          ? DTextStyle.textSubTitleBoldStyle2
                                          : DTextStyle.textSubTitleStyle,
                                    ),
                                  ),
                            Visibility(
                              visible: user.lastMessage!.status == 'unseen' &&
                                  user.lastMessage!.sender ==
                                      user.participant!.employeeId &&
                                  user.lastMessage!.unseen != 0,
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: const BoxDecoration(
                                    color: Colors.red, shape: BoxShape.circle),
                                alignment: Alignment.center,
                                child: Text(user.lastMessage!.unseen.toString(),
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                        fontSize: 10,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold)),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
