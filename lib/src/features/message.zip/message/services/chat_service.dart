// ignore_for_file: depend_on_referenced_packages

import 'dart:convert';

import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/utils/constants.dart';

class ChatService {
  static Future getAllUser() async {
    final box = GetStorage();
    Map<String, String>? headers = {
      "accept": "application/json",
      "authorization": "Bearer ${box.read('token')}"
    };
    var url = Uri.http(socketURL, 'api/get-all-connected-user');
    var response = await http
        .post(url, headers: headers, body: {"userId": box.read('employeeId')});
    if (response.statusCode == 200) {
      print(jsonDecode(response.body)['users']);
      return conversationModelFromJson(jsonDecode(response.body)['users']);
    } else {
      return {"error": "Server Error"};
    }
  }

  static Future getAllMessage({required conversationId}) async {
    final box = GetStorage();
    Map<String, String>? headers = {
      "accept": "application/json",
      "authorization": "Bearer ${box.read('token')}"
    };
    var url = Uri.http(socketURL, 'api/get-all-message');
    var response = await http
        .post(url, headers: headers, body: {"conversation_id": conversationId});
    if (response.statusCode == 200) {
      return jsonDecode(response.body)["messages"];
      // return conversationModelFromJson(jsonDecode(response.body)['data']);
    } else {
      return {"error": "Server Error"};
    }
  }

  static Future sendMessage(
      {required conversationId,
      required Participant participant,
      required String message,
      paths,
      required time}) async {
    final box = GetStorage();
    Map<String, String>? headers = {
      "accept": "application/json",
      "authorization": "Bearer ${box.read('token')}"
    };
    var url = Uri.http(socketURL, 'api/send-message');
    var data = {
      "userId": box.read('employeeId'),
      "userName": box.read('name'),
      "userAvatar": box.read('avater').toString(),
      "receiverId": participant.employeeId,
      "receiverName": participant.name,
      "receiverAvatar": participant.avatar,
      "conversationId": conversationId,
      "message": message,
      "attachments": paths.toString(),
      "time": time
    };
    var response = await http.post(url, headers: headers, body: data);
    if (response.statusCode == 200) {
      // print(response.body);
      // return conversationModelFromJson(jsonDecode(response.body)['data']);
    } else {
      return {"error": "Server Error"};
    }
  }

  static Future seenMessage(
      {required conversationId, required participantId}) async {
    final box = GetStorage();
    Map<String, String>? headers = {
      "accept": "application/json",
      "authorization": "Bearer ${box.read('token')}"
    };
    var url = Uri.http(socketURL, 'api/seen-message');
    var data = {
      "participantId": participantId,
      "conversationId": conversationId,
    };
    var response = await http.post(url, headers: headers, body: data);
    if (response.statusCode == 200) {
      // print(response.body);
      // return conversationModelFromJson(jsonDecode(response.body)['data']);
    } else {
      return {"error": "Server Error"};
    }
  }
}
