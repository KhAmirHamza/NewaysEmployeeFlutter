import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:neways3/src/features/message/bloc/IndividualChatController.dart';
import 'package:neways3/src/features/message/models/file_model.dart';
import 'package:neways3/src/features/message/widgets/customeBottomSheet.dart';
import 'package:neways3/src/utils/constants.dart';

Widget buildChatComposer(context) {
  return GetBuilder<IndividualChatController>(
      init: IndividualChatController(),
      builder: (controller) {
        return Column(
          children: [
            if (controller.files.isNotEmpty)
              Container(
                  color: Colors.transparent,
                  padding: EdgeInsets.symmetric(horizontal: DPadding.full),
                  alignment: Alignment.topLeft,
                  height: 155,
                  child: ListView.separated(
                    separatorBuilder: (BuildContext context, int index) =>
                        SizedBox(width: DPadding.half),
                    scrollDirection: Axis.horizontal,
                    itemCount: controller.files.length,
                    itemBuilder: ((context, index) {
                      FileModel file = controller.files[index];
                      String fileName = '';
                      if (file.extention == 'doc' || file.extention == 'docx') {
                        fileName = "doc.png";
                      } else if (file.extention == 'pdf') {
                        fileName = "pdf.png";
                      } else if (file.extention == 'txt') {
                        fileName = "txt.png";
                      }
                      return Stack(
                        // clipBehavior: Clip.none,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(DPadding.half),
                            child: file.extention == 'jpg'
                                ? Image.file(
                                    file.file,
                                    fit: BoxFit.cover,
                                  )
                                : Image.asset(
                                    "assets/icons/$fileName",
                                    fit: BoxFit.cover,
                                  ),
                          ),
                          Positioned(
                              top: 1,
                              right: 1,
                              child: InkWell(
                                onTap: () => controller.deleteImage(index),
                                child: Container(
                                    padding: EdgeInsets.all(DPadding.half / 2),
                                    decoration: BoxDecoration(
                                        color: Colors.red.withOpacity(0.75),
                                        borderRadius:
                                            BorderRadius.circular(50)),
                                    child: const Icon(
                                      Icons.close,
                                      color: Colors.white,
                                      size: 18,
                                    )),
                              ))
                        ],
                      );
                    }),
                  )),
            Container(
              padding: EdgeInsets.symmetric(horizontal: DPadding.full),
              color: Colors.white,
              height: 80,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      height: 48,
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Row(
                        children: [
                          Visibility(
                            visible: !controller.emojiShowing,
                            child: InkWell(
                              onTap: (() => controller.showEmojiState(true)),
                              child: const Icon(
                                Icons.emoji_emotions_outlined,
                                color: DColors.primary,
                              ),
                            ),
                          ),
                          Visibility(
                            visible: controller.emojiShowing,
                            child: InkWell(
                              onTap: (() => controller.showEmojiState(false)),
                              child: const Icon(
                                Icons.keyboard_alt_outlined,
                                color: DColors.primary,
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: TextField(
                              controller: controller.textController,
                              onChanged: (value) =>
                                  controller.onChangeMessage(value),
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Type your note ...',
                                hintStyle: TextStyle(color: Colors.grey[500]),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              showModalBottomSheet(
                                  backgroundColor: Colors.transparent,
                                  context: context,
                                  builder: (builder) =>
                                      const CustomeBottomSheet());
                            },
                            child: const Icon(
                              Icons.attach_file,
                              color: DColors.primary,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  const WidthSpace(),
                  !controller.isReadyToSend
                      ? const CircleAvatar(
                          backgroundColor: DColors.primary,
                          child: Icon(
                            Icons.mic,
                            size: 26,
                            color: Colors.white,
                          ))
                      : InkWell(
                          onTap: () {
                            // controller.scrollController.animateTo(
                            //     controller.scrollController.position
                            //         .maxScrollExtent,
                            //     duration: const Duration(milliseconds: 300),
                            //     curve: Curves.easeOut);
                            controller.sendMessage();
                          },
                          child: const CircleAvatar(
                            backgroundColor: DColors.primary,
                            child: Icon(
                              Icons.send_rounded,
                              size: 26,
                              color: Colors.white,
                            ),
                          ),
                        ),
                ],
              ),
            ),
            Offstage(
              offstage: !controller.emojiShowing,
              child: SizedBox(
                height: 250,
                child: EmojiPicker(
                    textEditingController: controller.textController,
                    onEmojiSelected: (category, Emoji emoji) {
                      // _onEmojiSelected(emoji);
                      controller.onChangeMessage(emoji);
                    },
                    onBackspacePressed: () => controller.onBackspacePressed(),
                    config: const Config(
                        columns: 7,
                        // Issue: https://github.com/flutter/flutter/issues/28894
                        emojiSizeMax: 32,
                        verticalSpacing: 0,
                        horizontalSpacing: 0,
                        gridPadding: EdgeInsets.zero,
                        initCategory: Category.RECENT,
                        bgColor: Color(0xFFF2F2F2),
                        indicatorColor: Colors.blue,
                        iconColor: Colors.grey,
                        iconColorSelected: Colors.blue,
                        backspaceColor: Colors.blue,
                        skinToneDialogBgColor: Colors.white,
                        skinToneIndicatorColor: Colors.grey,
                        enableSkinTones: true,
                        showRecentsTab: true,
                        recentsLimit: 28,
                        replaceEmojiOnLimitExceed: false,
                        noRecents: Text(
                          'No Recents',
                          style: TextStyle(fontSize: 20, color: Colors.black26),
                          textAlign: TextAlign.center,
                        ),
                        tabIndicatorAnimDuration: kTabScrollDuration,
                        categoryIcons: CategoryIcons(),
                        buttonMode: ButtonMode.MATERIAL)),
              ),
            ),
          ],
        );
      });
}
