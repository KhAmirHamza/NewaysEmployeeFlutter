// ignore_for_file: file_names, must_be_immutable

import 'package:cached_network_image/cached_network_image.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:neways3/src/utils/constants.dart';

class FileCard extends StatelessWidget {
  bool isFile;
  bool isMe;
  dynamic files;
  FileCard(
      {Key? key, required this.isMe, this.isFile = false, required this.files})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Align(
        alignment:
            isFile || isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: SizedBox(
          width: size.width * 0.65,
          // height: size.height / 2.5,
          child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: files.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: files.length == 1 ? 1 : 2,
              ),
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(DPadding.half)),
                  child: isFile
                      ? InkWell(
                          onTap: (() =>
                              _openCustomDialog(context, files[index])),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(DPadding.half),
                            child: Image.file(
                              files[index].file,
                              fit: BoxFit.cover,
                            ),
                          ),
                        )
                      : InkWell(
                          onTap: (() =>
                              _openCustomDialog(context, files[index])),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(DPadding.half),
                            child: ExtendedImage.network(
                              chatImageURL + files[index],
                              fit: BoxFit.cover,
                              enableLoadState: true,
                              cache: true,
                            ),
                          ),
                        ),
                );
              }),
        ));
  }

  void _openCustomDialog(context, data) {
    showGeneralDialog(
        barrierColor: Colors.black.withOpacity(0.5),
        transitionBuilder: (context, a1, a2, widget) {
          return Transform.scale(
            scale: a1.value,
            child: Opacity(
              opacity: a1.value,
              child: SafeArea(
                child: Container(
                  padding: EdgeInsets.all(DPadding.half),
                  // width: double.infinity,
                  child: isFile
                      ? InkWell(
                          onTap: (() => Get.back()),
                          child: ExtendedImage.file(
                            data.file,
                            fit: BoxFit.contain,
                            enableLoadState: true,
                            mode: ExtendedImageMode.gesture,
                            initGestureConfigHandler: (state) {
                              return GestureConfig(
                                minScale: 0.9,
                                animationMinScale: 0.7,
                                maxScale: 3.0,
                                animationMaxScale: 3.5,
                                speed: 1.0,
                                inertialSpeed: 100.0,
                                initialScale: 1.0,
                                inPageView: false,
                                initialAlignment: InitialAlignment.center,
                              );
                            },
                          ),
                        )
                      : InkWell(
                          onTap: (() => Get.back()),
                          child: ExtendedImage.network(
                            chatImageURL + data,
                            fit: BoxFit.contain,
                            enableLoadState: true,
                            mode: ExtendedImageMode.gesture,
                            initGestureConfigHandler: (state) {
                              return GestureConfig(
                                minScale: 0.9,
                                animationMinScale: 0.7,
                                maxScale: 3.0,
                                animationMaxScale: 3.5,
                                speed: 1.0,
                                inertialSpeed: 100.0,
                                initialScale: 1.0,
                                inPageView: false,
                                initialAlignment: InitialAlignment.center,
                              );
                            },
                          ),
                        ),
                ),
              ),
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 200),
        barrierDismissible: true,
        barrierLabel: '',
        context: context,
        pageBuilder: (context, animation1, animation2) => Container());
  }

  // popUpAds(url) {
  //   return Get.dialog(
  //     Stack(
  //       alignment: Alignment.center,
  //       children: [
  //         InkWell(
  //           // onTap: () async => _launchUrl(),
  //           child: CachedNetworkImage(
  //             imageUrl: url,
  //             progressIndicatorBuilder: (context, url, downloadProgress) =>
  //                 CircularProgressIndicator(value: downloadProgress.progress),
  //             errorWidget: (context, url, error) => const Icon(Icons.error),
  //           ),
  //         ),
  //         Positioned(
  //             right: 10,
  //             top: 10,
  //             child: IconButton(
  //                 color: Colors.black,
  //                 onPressed: () => Get.back(),
  //                 icon: const Icon(
  //                   Icons.close,
  //                   size: 24,
  //                   color: Colors.white,
  //                 )))
  //       ],
  //     ),
  //     barrierColor: Colors.black12.withOpacity(0.8),
  //     useSafeArea: true,
  //   );
  // }
}
