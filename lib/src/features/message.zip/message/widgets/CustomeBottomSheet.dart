// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:neways3/src/features/message/bloc/IndividualChatController.dart';
import 'package:neways3/src/utils/constants.dart';

class CustomeBottomSheet extends StatelessWidget {
  const CustomeBottomSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return bottomSheet(context);
  }

  Widget bottomSheet(context) {
    return GetBuilder<IndividualChatController>(
        init: IndividualChatController(),
        builder: (controller) {
          return SizedBox(
            height: 278,
            width: MediaQuery.of(context).size.width,
            child: Card(
              margin: const EdgeInsets.all(18.0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        iconCreation(Icons.insert_drive_file, "Document",
                            () => controller.getFile(context)),
                        const SizedBox(
                          width: 40,
                        ),
                        iconCreation(Icons.camera_alt, "Camera",
                            () => controller.getCameraImage(context)),
                        const SizedBox(
                          width: 40,
                        ),
                        iconCreation(Icons.insert_photo, "Gallery",
                            () => controller.getGalleryImage(context)),
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        iconCreation(Icons.headset, "Audio", () {}),
                        const SizedBox(
                          width: 40,
                        ),
                        iconCreation(Icons.location_pin, "Location", () {}),
                        const SizedBox(
                          width: 40,
                        ),
                        iconCreation(Icons.person, "Contact", () {}),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }

  Widget iconCreation(IconData icons, String text, VoidCallback onPress) {
    return InkWell(
      onTap: onPress,
      child: Column(
        children: [
          // CircleAvatar(
          //   radius: 30,
          //   backgroundColor: color,
          //   child: Icon(
          //     icons,
          //     // semanticLabel: "Help",
          //     size: 29,
          //     color: Colors.white,
          //   ),
          // ),
          Container(
            padding: EdgeInsets.all(DPadding.full),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(DPadding.full),
            ),
            child: Icon(
              icons,
              // semanticLabel: "Help",
              size: 29,
              color: Colors.black,
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
            text,
            style: const TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w100,
            ),
          )
        ],
      ),
    );
  }
}
