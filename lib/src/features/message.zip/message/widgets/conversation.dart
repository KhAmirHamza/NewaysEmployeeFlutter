// ignore_for_file: unused_import

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:neways3/src/features/message/bloc/ChatListController.dart';
import 'package:neways3/src/features/message/bloc/IndividualChatController.dart';
import 'package:neways3/src/features/message/models/ConversationModel.dart';
import 'package:neways3/src/features/message/widgets/FileCard.dart';
import 'package:neways3/src/utils/constants.dart';
import 'package:timeago/timeago.dart' as timeago;

class Conversation extends StatelessWidget {
  const Conversation({
    Key? key,
    required this.user,
  }) : super(key: key);

  final ConversationModel user;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: GetBuilder<IndividualChatController>(
              init: IndividualChatController(),
              builder: (controller) {
                return ListView.builder(
                    reverse: controller.isReverse,
                    controller: controller.scrollController,
                    itemCount: controller.messages.length + 1,
                    itemBuilder: (context, int index) {
                      if (controller.messages.length == index) {
                        return const SizedBox(height: 80);
                      }
                      final message = controller.messages[index];
                      bool isMe =
                          message.sender == GetStorage().read('employeeId');

                      return Container(
                        margin: const EdgeInsets.only(top: 10),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: isMe
                                  ? MainAxisAlignment.end
                                  : MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                if (!isMe)
                                  CircleAvatar(
                                    radius: 15,
                                    backgroundImage:
                                        NetworkImage(user.participant!.avatar),
                                  ),
                                const SizedBox(
                                  width: 10,
                                ),
                                Column(
                                  crossAxisAlignment: isMe
                                      ? CrossAxisAlignment.end
                                      : CrossAxisAlignment.start,
                                  children: [
                                    Visibility(
                                        visible: message.files != null &&
                                            message.files!.isNotEmpty,
                                        child: FileCard(
                                            isMe: isMe,
                                            isFile: message.isFile,
                                            files: message.files)),
                                    Visibility(
                                      visible: message.text.isNotEmpty,
                                      child: Container(
                                        padding: const EdgeInsets.all(10),
                                        constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.65),
                                        decoration: BoxDecoration(
                                            color: isMe
                                                ? Colors.blue
                                                : Colors.grey[200],
                                            borderRadius: BorderRadius.only(
                                              topLeft:
                                                  const Radius.circular(16),
                                              topRight:
                                                  const Radius.circular(16),
                                              bottomLeft: Radius.circular(
                                                  isMe ? 12 : 0),
                                              bottomRight: Radius.circular(
                                                  isMe ? 0 : 12),
                                            )),
                                        child: SelectableText(
                                          message.text,
                                          style: TextStyle(
                                              color: isMe
                                                  ? Colors.white
                                                  : Colors.grey[800]),
                                        ),
                                      ),
                                    ),
                                    // Text(controller.participant.name,
                                    //     style:
                                    //         TextStyle(fontWeight: FontWeight.bold)),
                                  ],
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Row(
                                mainAxisAlignment: isMe
                                    ? MainAxisAlignment.end
                                    : MainAxisAlignment.start,
                                children: [
                                  if (!isMe)
                                    const SizedBox(
                                      width: 40,
                                    ),
                                  Text(
                                    message.time,
                                    style: const TextStyle(color: Colors.grey),
                                  ),
                                  const SizedBox(
                                    width: 8,
                                  ),
                                  Visibility(
                                    visible: isMe,
                                    child: message.status == 'seen'
                                        ? const Icon(
                                            Icons.done_all,
                                            size: 20,
                                            color: Colors.blue,
                                          )
                                        : const Icon(
                                            Icons.done,
                                            size: 20,
                                            color: Colors.grey,
                                          ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      );
                    });
              }),
        ),
        GetBuilder<ChatListController>(
            init: ChatListController(),
            builder: (chatController) {
              return Visibility(
                visible: chatController.isTyping &&
                    chatController.typperId == user.participant!.employeeId,
                child: Padding(
                  padding: EdgeInsets.only(top: DPadding.half),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 15,
                        backgroundImage: NetworkImage(user.participant!.avatar),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            // width: MediaQuery.of(context).size.width * 0.65,
                            constraints: BoxConstraints(
                                maxWidth:
                                    MediaQuery.of(context).size.width * 0.65),
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(16),
                                  topRight: Radius.circular(16),
                                  bottomLeft: Radius.circular(0),
                                  bottomRight: Radius.circular(12),
                                )),
                            child: AnimatedTextKit(
                              repeatForever: true,
                              animatedTexts: [
                                TyperAnimatedText(
                                  'Typing...',
                                  textStyle: DTextStyle.textSubTitleStyle,
                                ),
                              ],
                            ),
                          ),
                          // Text(controller.participant.name,
                          //     style:
                          //         TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            })
      ],
    );
  }
}
