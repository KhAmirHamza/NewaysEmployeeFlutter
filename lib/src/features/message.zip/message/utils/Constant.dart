//const chatUrl = "http://116.68.198.178:5005"; //Real Server
//const chatUrl = "http://10.100.105.200:5005"; //Real Server-Local
const chatUrl = "http://10.100.93.84:3000"; //Local Server
